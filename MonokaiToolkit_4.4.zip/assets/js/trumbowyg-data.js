(function ($) {
    'use strict';
    $.trumbowyg.svgPath = 'assets/vendor/trumbowyg/ui/icons.svg';


    $("#trumbowyg").trumbowyg();

})(window.jQuery);